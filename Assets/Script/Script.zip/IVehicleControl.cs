
public interface IVehicleControl
{
    void Control();
}
